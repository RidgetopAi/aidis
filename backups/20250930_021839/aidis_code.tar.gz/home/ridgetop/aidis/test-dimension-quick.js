#!/usr/bin/env node

/**
 * Quick embedding dimension verification
 */

const { spawn } = require('child_process');

async function quickTest() {
  console.log('🧪 Quick Phase 4 Dimension Test\n');

  // Start server
  console.log('Starting Phase 4 server...');
  const server = spawn('npx', ['tsx', 'aidis-rebuild-p4.ts'], {
    stdio: ['pipe', 'pipe', 'inherit']
  });

  let serverReady = false;
  server.stdout.on('data', (data) => {
    const output = data.toString();
    if (output.includes('Enhanced AIDIS MCP Server (Phase 4) listening')) {
      serverReady = true;
    }
  });

  // Wait for server
  await new Promise(resolve => {
    const check = () => {
      if (serverReady) {
        console.log('✅ Server ready\n');
        resolve();
      } else {
        setTimeout(check, 100);
      }
    };
    check();
  });

  // Wait a bit more
  await new Promise(resolve => setTimeout(resolve, 2000));

  // Test context_store
  console.log('Testing context_store...');
  const testStore = {
    jsonrpc: "2.0",
    method: "tools/call",
    params: {
      name: "context_store",
      arguments: {
        content: "Quick dimension test for 384-dimensional embedding vectors",
        type: "code",
        tags: ["test", "dimensions"]
      }
    },
    id: "quick-test"
  };

  const curl = spawn('curl', [
    '-X', 'POST',
    'http://localhost:5001',
    '-H', 'Content-Type: application/json',
    '-d', JSON.stringify(testStore)
  ], { stdio: 'pipe' });

  let result = '';
  curl.stdout.on('data', data => result += data.toString());

  await new Promise(resolve => curl.on('close', resolve));

  try {
    const response = JSON.parse(result);
    if (response.result && response.result.content[0].text.includes('384 dimensions')) {
      console.log('✅ context_store: 384 dimensions confirmed');
    } else {
      console.log('❌ context_store issue:', response.result?.content[0]?.text?.substring(0, 100));
    }
  } catch (e) {
    console.log('❌ Parse error:', result.substring(0, 100));
  }

  // Cleanup
  server.kill();
  console.log('\n🎯 Quick Test Complete!');
}

quickTest().catch(console.error);
