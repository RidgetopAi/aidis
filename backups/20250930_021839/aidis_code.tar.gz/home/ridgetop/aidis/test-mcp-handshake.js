#!/usr/bin/env node

/**
 * Manual MCP Protocol Handshake Test
 * 
 * This script manually sends MCP initialize and list_tools requests
 * to AIDIS server to test if it responds correctly.
 */

const { spawn } = require('child_process');
const path = require('path');

function sendMCPRequest(request) {
  return new Promise((resolve, reject) => {
    const serverPath = path.resolve(__dirname, 'mcp-server/src/server.ts');
    const tsxPath = path.resolve(__dirname, 'mcp-server/node_modules/.bin/tsx');
    
    console.log('🚀 Starting AIDIS server...');
    console.log('📍 Server path:', serverPath);
    console.log('📍 TSX path:', tsxPath);
    
    const child = spawn(tsxPath, [serverPath], {
      cwd: path.resolve(__dirname, 'mcp-server'),
      env: {
        ...process.env,
        NODE_ENV: 'development',
        AMP_CONNECTING: 'true',
        AIDIS_FORCE_STDIO: 'true',
        AIDIS_MCP_DEBUG: '1'
      },
      stdio: ['pipe', 'pipe', 'pipe']
    });

    let stdout = '';
    let stderr = '';
    let responseReceived = false;
    
    // Send the request after a small delay
    setTimeout(() => {
      console.log('📤 Sending MCP request:', JSON.stringify(request));
      child.stdin.write(JSON.stringify(request) + '\n');
    }, 2000);
    
    child.stdout.on('data', (data) => {
      const chunk = data.toString();
      stdout += chunk;
      
      console.log('📥 STDOUT:', chunk.trim());
      
      // Look for JSON responses
      const lines = chunk.split('\n');
      for (const line of lines) {
        if (line.trim() && line.startsWith('{')) {
          try {
            const response = JSON.parse(line.trim());
            console.log('✅ MCP Response received:', JSON.stringify(response, null, 2));
            responseReceived = true;
            child.kill();
            resolve({ response, stdout, stderr });
            return;
          } catch (e) {
            // Not a JSON line, continue
          }
        }
      }
    });

    child.stderr.on('data', (data) => {
      const chunk = data.toString();
      stderr += chunk;
      console.log('📜 STDERR:', chunk.trim());
    });

    child.on('close', (code) => {
      console.log(`🔚 Process exited with code: ${code}`);
      if (!responseReceived) {
        resolve({ response: null, stdout, stderr, exitCode: code });
      }
    });

    child.on('error', (error) => {
      console.error('❌ Process error:', error);
      reject(error);
    });

    // Timeout after 10 seconds
    setTimeout(() => {
      if (!responseReceived) {
        console.log('⏰ Timeout - killing process');
        child.kill();
        resolve({ response: null, stdout, stderr, timeout: true });
      }
    }, 10000);
  });
}

async function testMCPHandshake() {
  console.log('🧪 Testing MCP Protocol Handshake with AIDIS\n');

  // Test 1: Initialize request
  console.log('=== Test 1: Initialize Request ===');
  const initializeRequest = {
    jsonrpc: '2.0',
    id: 1,
    method: 'initialize',
    params: {
      protocolVersion: '2024-11-05',
      capabilities: {
        tools: {}
      },
      clientInfo: {
        name: 'amp-test-client',
        version: '1.0.0'
      }
    }
  };

  const initResult = await sendMCPRequest(initializeRequest);
  console.log('\n📊 Initialize Result:');
  console.log('Response:', initResult.response ? 'RECEIVED' : 'NONE');
  console.log('Exit code:', initResult.exitCode);
  console.log('Timeout:', initResult.timeout || false);

  // Test 2: List tools request
  console.log('\n=== Test 2: List Tools Request ===');
  const listToolsRequest = {
    jsonrpc: '2.0',
    id: 2,
    method: 'tools/list',
    params: {}
  };

  const toolsResult = await sendMCPRequest(listToolsRequest);
  console.log('\n📊 List Tools Result:');
  console.log('Response:', toolsResult.response ? 'RECEIVED' : 'NONE');
  console.log('Exit code:', toolsResult.exitCode);
  console.log('Timeout:', toolsResult.timeout || false);

  // Summary
  console.log('\n=== Summary ===');
  console.log('Initialize response:', initResult.response ? '✅ SUCCESS' : '❌ FAILED');
  console.log('List tools response:', toolsResult.response ? '✅ SUCCESS' : '❌ FAILED');
  
  if (!initResult.response && !toolsResult.response) {
    console.log('\n🔍 Debugging Info:');
    console.log('- AIDIS server may not be responding to MCP requests');
    console.log('- Check if server is properly listening on stdin/stdout');
    console.log('- Verify MCP protocol implementation');
    console.log('- Look for initialization issues in server logs');
  }
}

testMCPHandshake().catch(console.error);
