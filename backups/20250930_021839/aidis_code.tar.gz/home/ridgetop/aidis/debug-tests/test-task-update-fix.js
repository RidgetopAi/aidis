const { exec } = require('child_process');
const { promisify } = require('util');

const execAsync = promisify(exec);

async function testTaskUpdate() {
    console.log('🔧 Testing AIDIS task_update fix...');
    
    try {
        // Test the task update with urgent priority and progress
        console.log('📋 Testing task update with urgent priority and progress...');
        
        const testTaskId = '45f542a7-01e9-4025-9a1e-36d103652a7c';
        const testData = {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                taskId: testTaskId,
                priority: 'urgent',
                progress: 90,
                status: 'in_progress'
            })
        };

        // Test using curl to the AIDIS HTTP API directly
        const curl = `curl -X POST -H "Content-Type: application/json" \\
            -d '{"taskId":"${testTaskId}","priority":"urgent","progress":90,"status":"in_progress"}' \\
            http://localhost:8080/mcp/task_update`;
            
        console.log('🌐 Testing HTTP API directly...');
        console.log('Command:', curl);
        
        const { stdout, stderr } = await execAsync(curl);
        
        if (stderr) {
            console.error('❌ Error:', stderr);
        }
        
        if (stdout) {
            console.log('✅ Response:', stdout);
        }
        
    } catch (error) {
        console.error('❌ Test failed:', error.message);
        console.log('📊 Error details:', error);
    }
}

// Run test
testTaskUpdate().catch(console.error);
