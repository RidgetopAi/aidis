#!/usr/bin/env node

const axios = require('axios');

const BASE_URL = 'http://localhost:5000/api';

let authToken = null;

async function login() {
  try {
    console.log('🔐 Logging in to get auth token...');
    
    const loginResponse = await axios.post(`${BASE_URL}/auth/login`, {
      username: 'admin',
      password: 'admin123!'
    });
    
    authToken = loginResponse.data.token;
    console.log('✅ Login successful, token obtained');
    return authToken;
  } catch (error) {
    console.error('❌ Login failed:', error.response?.data || error.message);
    throw error;
  }
}

async function testHealthEndpoint() {
  try {
    console.log('\n📊 Testing health endpoint...');
    
    const response = await axios.get(`${BASE_URL}/health`);
    console.log('✅ Health check:', response.data);
    return true;
  } catch (error) {
    console.error('❌ Health check failed:', error.response?.data || error.message);
    return false;
  }
}

async function testProjectStats() {
  try {
    console.log('\n📊 Testing project stats endpoint...');
    
    const response = await axios.get(`${BASE_URL}/projects/stats`, {
      headers: { Authorization: `Bearer ${authToken}` }
    });
    
    console.log('✅ Project stats response:');
    console.log(JSON.stringify(response.data, null, 2));
    return response.data;
  } catch (error) {
    console.error('❌ Project stats failed:', error.response?.data || error.message);
    throw error;
  }
}

async function testContextStats() {
  try {
    console.log('\n📊 Testing context stats endpoint...');
    
    const response = await axios.get(`${BASE_URL}/contexts/stats`, {
      headers: { Authorization: `Bearer ${authToken}` }
    });
    
    console.log('✅ Context stats response:');
    console.log(JSON.stringify(response.data, null, 2));
    return response.data;
  } catch (error) {
    console.error('❌ Context stats failed:', error.response?.data || error.message);
    throw error;
  }
}

async function testDashboardDataFlow() {
  try {
    console.log('\n🔄 Testing complete dashboard data flow...');
    
    // Simulate what the frontend dashboardApi.getDashboardStats() does
    const [projectStatsResponse, contextStatsResponse] = await Promise.all([
      axios.get(`${BASE_URL}/projects/stats`, {
        headers: { Authorization: `Bearer ${authToken}` }
      }),
      axios.get(`${BASE_URL}/contexts/stats`, {
        headers: { Authorization: `Bearer ${authToken}` }
      })
    ]);
    
    const projectStats = projectStatsResponse.data.data.stats;
    const contextStats = contextStatsResponse.data.data;
    
    console.log('\n📋 Project stats structure:', Object.keys(projectStats));
    console.log('📋 Context stats structure:', Object.keys(contextStats));
    
    // Combine data like the frontend does
    const dashboardStats = {
      contexts: contextStats.total_contexts || contextStats.total,
      agents: 0, // TODO: Add agents endpoint
      projects: projectStats.total_projects,
      activeTasks: 0, // TODO: Add tasks endpoint
      recentActivity: {
        contextsThisWeek: projectStats.recent_activity?.contexts_last_week || 0,
        sessionsThisWeek: projectStats.recent_activity?.sessions_last_week || 0
      }
    };
    
    console.log('\n✅ Combined dashboard stats:');
    console.log(JSON.stringify(dashboardStats, null, 2));
    
    // Check if any values are null or undefined
    const hasNullValues = Object.values(dashboardStats).some(val => 
      val === null || val === undefined || (typeof val === 'number' && isNaN(val))
    );
    
    if (hasNullValues) {
      console.log('\n⚠️  WARNING: Dashboard stats contain null/undefined values!');
    } else {
      console.log('\n✅ All dashboard stats have valid values!');
    }
    
    return dashboardStats;
    
  } catch (error) {
    console.error('❌ Dashboard data flow test failed:', error.response?.data || error.message);
    throw error;
  }
}

async function checkDatabaseHasData() {
  try {
    console.log('\n🗄️  Checking if database has actual data...');
    
    // Check if we have any projects
    const projectsResponse = await axios.get(`${BASE_URL}/projects`, {
      headers: { Authorization: `Bearer ${authToken}` }
    });
    
    const projects = projectsResponse.data.data.projects;
    console.log(`📦 Found ${projects.length} projects in database`);
    
    if (projects.length > 0) {
      console.log('📦 Sample project:', projects[0]);
    }
    
    // Check if we have any contexts
    const contextsResponse = await axios.get(`${BASE_URL}/contexts`, {
      headers: { Authorization: `Bearer ${authToken}` }
    });
    
    const contexts = contextsResponse.data.data.contexts || contextsResponse.data.data;
    console.log(`📄 Found ${contexts.length} contexts in database`);
    
    if (contexts.length > 0) {
      console.log('📄 Sample context:', {
        id: contexts[0].id,
        type: contexts[0].context_type,
        project_id: contexts[0].project_id
      });
    }
    
    return { projectCount: projects.length, contextCount: contexts.length };
    
  } catch (error) {
    console.error('❌ Database check failed:', error.response?.data || error.message);
    throw error;
  }
}

async function main() {
  console.log('🚀 Starting dashboard API debugging...\n');
  
  try {
    // Test health first
    const healthOk = await testHealthEndpoint();
    if (!healthOk) {
      console.log('❌ Backend server is not responding');
      process.exit(1);
    }
    
    // Login to get auth token
    await login();
    
    // Check actual database data
    const dbData = await checkDatabaseHasData();
    
    // Test individual endpoints
    await testProjectStats();
    await testContextStats();
    
    // Test the complete data flow
    await testDashboardDataFlow();
    
    console.log('\n✅ All tests completed!');
    
  } catch (error) {
    console.error('\n❌ Test suite failed:', error.message);
    process.exit(1);
  }
}

// Run the tests
main().catch(console.error);
