const { Client } = require('./mcp-server/node_modules/@modelcontextprotocol/sdk/client/index.js');
const { StdioClientTransport } = require('./mcp-server/node_modules/@modelcontextprotocol/sdk/client/stdio.js');

async function testDecisionUpdate() {
  console.log('🧪 Testing decision_update fix...');
  
  const transport = new StdioClientTransport({
    command: 'npx',
    args: ['tsx', 'mcp-server/src/server.ts'],
  });

  const client = new Client({
    name: 'test-decision-update',
    version: '1.0.0',
  });

  try {
    await client.connect(transport);
    console.log('✅ MCP client connected');

    // Test decision_record first 
    const recordResult = await client.request({
      method: 'tools/call',
      params: {
        name: 'decision_record',
        arguments: {
          title: 'Test Decision Update Fix',
          description: 'Testing the decision update functionality after schema fix',  
          rationale: 'To verify updated_at column works properly',
          decisionType: 'testing',
          impactLevel: 'low'
        }
      }
    });

    console.log('📝 Decision recorded:', recordResult.content[0].text);
    const decisionData = JSON.parse(recordResult.content[0].text);
    const decisionId = decisionData.decisionId;

    if (!decisionId) {
      throw new Error('Failed to get decisionId from record result');
    }

    // Test decision_update with the new decision
    console.log('🔄 Testing decision_update with ID:', decisionId);
    const updateResult = await client.request({
      method: 'tools/call',
      params: {
        name: 'decision_update',
        arguments: {
          decisionId: decisionId,
          outcomeStatus: 'successful', 
          outcomeNotes: 'The updated_at column is working correctly after migration 009',
          lessonsLearned: 'Database schema issues can be resolved with proper migrations'
        }
      }
    });

    console.log('✅ Update successful:', updateResult.content[0].text);
    
    // Verify the updated_at column was set
    const updatedData = JSON.parse(updateResult.content[0].text);
    if (updatedData.updatedAt) {
      console.log('✅ updated_at column is working properly');
    } else {
      console.log('⚠️  updated_at column not found in response');
    }

    console.log('\n🎉 Decision update test completed successfully!');
    
  } catch (error) {
    console.error('❌ Test failed:', error.message);
    process.exit(1);
  } finally {
    await client.close();
  }
}

testDecisionUpdate();
