// Debug script to inject into browser console to monitor auth state
console.log('🔍 AIDIS AUTH DEBUG SCRIPT LOADED');

// Monitor localStorage changes
const originalSetItem = localStorage.setItem;
const originalRemoveItem = localStorage.removeItem;
const originalClear = localStorage.clear;

localStorage.setItem = function(key, value) {
    console.log(`🔧 localStorage.setItem: ${key} = ${value.substring(0, 50)}...`);
    return originalSetItem.apply(this, arguments);
};

localStorage.removeItem = function(key) {
    console.log(`🗑️ localStorage.removeItem: ${key}`);
    return originalRemoveItem.apply(this, arguments);
};

localStorage.clear = function() {
    console.log('🗑️ localStorage.clear()');
    return originalClear.apply(this, arguments);
};

// Check current localStorage state
console.log('📦 Current localStorage contents:');
for (let i = 0; i < localStorage.length; i++) {
    const key = localStorage.key(i);
    const value = localStorage.getItem(key);
    console.log(`  ${key}: ${value}`);
}

// Monitor URL changes
let currentUrl = window.location.href;
const checkUrlChange = () => {
    if (window.location.href !== currentUrl) {
        console.log(`🌐 URL changed: ${currentUrl} → ${window.location.href}`);
        currentUrl = window.location.href;
    }
    setTimeout(checkUrlChange, 500);
};
checkUrlChange();

// Monitor any authentication-related console logs
const originalConsoleLog = console.log;
const originalConsoleWarn = console.warn;
const originalConsoleError = console.error;

console.log = function() {
    const message = Array.from(arguments).join(' ');
    if (message.includes('auth') || message.includes('token') || message.includes('login') || message.includes('401')) {
        originalConsoleLog('🔍 AUTH-RELATED:', ...arguments);
    }
    return originalConsoleLog.apply(this, arguments);
};

console.warn = function() {
    const message = Array.from(arguments).join(' ');
    if (message.includes('auth') || message.includes('token') || message.includes('login') || message.includes('401')) {
        originalConsoleWarn('⚠️ AUTH-WARNING:', ...arguments);
    }
    return originalConsoleWarn.apply(this, arguments);
};

console.error = function() {
    const message = Array.from(arguments).join(' ');
    if (message.includes('auth') || message.includes('token') || message.includes('login') || message.includes('401')) {
        originalConsoleError('❌ AUTH-ERROR:', ...arguments);
    }
    return originalConsoleError.apply(this, arguments);
};

// Check if React DevTools is available and try to inspect component state
setTimeout(() => {
    if (window.__REACT_DEVTOOLS_GLOBAL_HOOK__) {
        console.log('⚛️ React DevTools detected - you can inspect component state');
    }
    
    // Try to find the auth state in the DOM
    const authElements = document.querySelectorAll('[data-testid*="auth"], [class*="auth"], [id*="auth"]');
    if (authElements.length > 0) {
        console.log(`🔍 Found ${authElements.length} auth-related DOM elements`);
    }
    
    // Check if we're on login or dashboard
    const currentPath = window.location.pathname;
    console.log(`📍 Current path: ${currentPath}`);
    
    if (currentPath === '/login') {
        console.log('✅ On login page - this is correct if not authenticated');
    } else if (currentPath.startsWith('/dashboard') || currentPath === '/') {
        console.log('⚠️ On dashboard/home - this suggests authentication is working');
        console.log('   If localStorage is empty, there might be an issue');
    }
    
}, 1000);

console.log('✅ Debug script ready! Watch console for auth-related activity.');
