#!/usr/bin/env node

const { chromium } = require('playwright');

async function testDashboardInBrowser() {
  let browser;
  try {
    console.log('🚀 Starting browser test for dashboard stats...');
    
    // Launch browser
    browser = await chromium.launch({ 
      headless: false,
      args: ['--disable-web-security', '--disable-features=VizDisplayCompositor']
    });
    const context = await browser.newContext();
    const page = await context.newPage();
    
    // Listen to console logs
    const consoleLogs = [];
    page.on('console', msg => {
      const text = msg.text();
      console.log(`📋 [${msg.type()}] ${text}`);
      consoleLogs.push({ type: msg.type(), text });
    });
    
    // Listen to network requests
    page.on('request', request => {
      if (request.url().includes('/api/')) {
        console.log(`🌐 Request: ${request.method()} ${request.url()}`);
      }
    });
    
    page.on('response', response => {
      if (response.url().includes('/api/')) {
        console.log(`📡 Response: ${response.status()} ${response.url()}`);
      }
    });
    
    // Navigate to the frontend
    console.log('🌐 Navigating to frontend...');
    await page.goto('http://localhost:3000');
    
    // Wait for page to load
    await page.waitForTimeout(2000);
    
    // Check if there's a login page
    const loginForm = await page.$('form');
    if (loginForm) {
      console.log('🔐 Found login form, attempting login...');
      
      // Fill login form
      await page.fill('input[name="username"]', 'admin');
      await page.fill('input[name="password"]', 'admin123!');
      await page.click('button[type="submit"]');
      
      // Wait for navigation after login
      await page.waitForTimeout(3000);
    }
    
    // Look for dashboard stats
    console.log('📊 Looking for dashboard elements...');
    
    // Wait for dashboard to load and check if stats are displayed
    await page.waitForTimeout(5000);
    
    // Take a screenshot for debugging
    await page.screenshot({ path: 'dashboard-screenshot.png', fullPage: true });
    console.log('📷 Screenshot saved as dashboard-screenshot.png');
    
    // Check for stats values
    const statsElements = await page.$$('[data-testid*="stat"], .ant-statistic-content, .ant-statistic-content-value');
    
    if (statsElements.length > 0) {
      console.log('🎯 Found stats elements:');
      for (let i = 0; i < Math.min(statsElements.length, 10); i++) {
        try {
          const text = await statsElements[i].textContent();
          console.log(`  - Element ${i}: "${text}"`);
        } catch (e) {
          console.log(`  - Element ${i}: (couldn't read text)`);
        }
      }
    } else {
      console.log('❌ No stats elements found on page');
    }
    
    // Check for specific stat values
    const contextsStat = await page.$('text=Total Contexts');
    const projectsStat = await page.$('text=Projects');
    const agentsStat = await page.$('text=Active Agents');
    
    if (contextsStat) {
      console.log('✅ Found "Total Contexts" element');
    }
    if (projectsStat) {
      console.log('✅ Found "Projects" element');
    }
    if (agentsStat) {
      console.log('✅ Found "Active Agents" element');
    }
    
    // Look for any error messages or loading states
    const errorMessages = await page.$$('.ant-alert-error, .error, [data-testid="error"]');
    const loadingStates = await page.$$('.ant-spin, .loading, [data-testid="loading"]');
    
    if (errorMessages.length > 0) {
      console.log('⚠️  Found error messages:');
      for (const error of errorMessages) {
        const text = await error.textContent();
        console.log(`  - Error: ${text}`);
      }
    }
    
    if (loadingStates.length > 0) {
      console.log('⏳ Found loading states - page may still be loading');
    }
    
    // Check console logs for API calls and errors
    const apiLogs = consoleLogs.filter(log => 
      log.text.includes('Dashboard API') || 
      log.text.includes('dashboard stats') ||
      log.text.includes('API Health') ||
      log.text.includes('fetch')
    );
    
    if (apiLogs.length > 0) {
      console.log('🔍 Relevant console logs:');
      apiLogs.forEach(log => {
        console.log(`  [${log.type}] ${log.text}`);
      });
    }
    
    // Wait a bit more to see if data loads
    console.log('⏳ Waiting for data to load...');
    await page.waitForTimeout(5000);
    
    // Final check for stats
    const finalStats = await page.$$eval('.ant-statistic-content-value', elements => 
      elements.map(el => el.textContent)
    );
    
    console.log('📈 Final stats values on page:', finalStats);
    
    // Check if all stats show 0 or null
    const hasValidStats = finalStats.some(stat => {
      const num = parseInt(stat);
      return !isNaN(num) && num > 0;
    });
    
    if (hasValidStats) {
      console.log('✅ SUCCESS: Dashboard is showing valid stats!');
      return true;
    } else {
      console.log('❌ FAILURE: Dashboard is still showing 0/null values');
      return false;
    }
    
  } catch (error) {
    console.error('❌ Browser test failed:', error);
    return false;
  } finally {
    if (browser) {
      await browser.close();
    }
  }
}

async function main() {
  console.log('🧪 Starting comprehensive dashboard test...\n');
  
  const success = await testDashboardInBrowser();
  
  if (success) {
    console.log('\n🎉 DASHBOARD TEST PASSED! Stats are working correctly.');
  } else {
    console.log('\n💥 DASHBOARD TEST FAILED! Stats are still showing null/0 values.');
    console.log('\nDebugging suggestions:');
    console.log('1. Check dashboard-screenshot.png to see what the UI looks like');
    console.log('2. Check browser console logs for API errors');
    console.log('3. Verify frontend is connecting to backend properly');
    console.log('4. Check if authentication token is being passed correctly');
  }
}

// Add error handling
process.on('unhandledRejection', (error) => {
  console.error('Unhandled promise rejection:', error);
  process.exit(1);
});

main().catch(console.error);
