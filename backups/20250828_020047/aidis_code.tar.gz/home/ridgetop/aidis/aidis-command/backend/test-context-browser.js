const { chromium } = require('playwright');
const fs = require('fs').promises;
const path = require('path');

async function testContextBrowser() {
  console.log('🚀 Testing Context Browser with Playwright');
  
  const browser = await chromium.launch({ headless: true });
  const context = await browser.newContext();
  const page = await context.newPage();

  // Create debug-images directory
  const debugDir = path.join(__dirname, '../debug-images');
  try {
    await fs.mkdir(debugDir, { recursive: true });
  } catch (e) {
    // Directory already exists
  }

  // Listen for console errors
  page.on('console', msg => {
    if (msg.type() === 'error') {
      console.log('❌ Browser Error:', msg.text());
    }
  });

  // Listen for network requests
  page.on('response', response => {
    if (response.url().includes('/api/contexts')) {
      console.log(`📡 API Request: ${response.request().method()} ${response.url()} - Status: ${response.status()}`);
    }
  });

  try {
    // Navigate to Context Browser
    console.log('📍 Loading Context Browser...');
    await page.goto('http://localhost:3000', { waitUntil: 'networkidle' });

    // Wait for any authentication or loading
    await page.waitForTimeout(2000);

    // Take screenshot
    const screenshotPath = path.join(debugDir, `context-browser-${Date.now()}.png`);
    await page.screenshot({ path: screenshotPath, fullPage: true });
    console.log(`📸 Screenshot saved: ${screenshotPath}`);

    // Check for 401 errors in the page content
    const pageContent = await page.content();
    if (pageContent.includes('401') || pageContent.includes('Unauthorized')) {
      console.log('⚠️  401 error detected in page content');
    }

    // Check if Context Browser loaded successfully
    const title = await page.title();
    console.log(`📄 Page title: ${title}`);

    // Look for specific elements
    const hasError = await page.locator('text=/error|Error|401|Unauthorized/i').count() > 0;
    const hasContexts = await page.locator('text=/context|Context/i').count() > 0;

    console.log(`✅ Has error messages: ${hasError}`);
    console.log(`✅ Has context elements: ${hasContexts}`);

  } catch (error) {
    console.error('❌ Test failed:', error);
    
    // Take error screenshot
    const errorScreenshot = path.join(debugDir, `error-${Date.now()}.png`);
    await page.screenshot({ path: errorScreenshot });
    console.log(`📸 Error screenshot: ${errorScreenshot}`);
  } finally {
    await browser.close();
  }
}

// Test the authentication endpoint directly
async function testAuthEndpoint() {
  console.log('\n🔑 Testing authentication endpoint...');
  
  try {
    const response = await fetch('http://localhost:3001/api/auth/login', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        username: 'admin',
        password: 'aidis123'
      })
    });

    console.log(`🌐 Auth endpoint status: ${response.status}`);
    
    if (response.ok) {
      const data = await response.json();
      console.log('✅ Authentication successful');
      
      // Test contexts endpoint with token
      const token = data.data?.token;
      if (token) {
        console.log('\n📋 Testing contexts endpoint...');
        const contextResponse = await fetch('http://localhost:3001/api/contexts', {
          headers: {
            'Authorization': `Bearer ${token}`,
            'Content-Type': 'application/json'
          }
        });
        
        console.log(`📡 Contexts endpoint status: ${contextResponse.status}`);
        
        if (contextResponse.ok) {
          const contexts = await contextResponse.json();
          console.log(`✅ Contexts loaded: ${contexts.data?.length || 0} items`);
        } else {
          const errorText = await contextResponse.text();
          console.log(`❌ Contexts failed: ${errorText}`);
        }
      }
    } else {
      const errorText = await response.text();
      console.log(`❌ Authentication failed: ${errorText}`);
    }
  } catch (error) {
    console.error('❌ Auth test failed:', error.message);
  }
}

// Run tests
async function runTests() {
  console.log('🔧 AIDIS Context Browser Debug Test\n');
  
  await testAuthEndpoint();
  await testContextBrowser();
  
  console.log('\n✅ Debug tests completed');
}

runTests().catch(console.error);
