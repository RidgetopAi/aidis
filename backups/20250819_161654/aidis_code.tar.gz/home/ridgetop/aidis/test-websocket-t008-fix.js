#!/usr/bin/env node

/**
 * T008 WebSocket Authentication Fix Test
 * Tests WebSocket connection and real-time task updates
 * Compares with working T007 patterns
 */

const WebSocket = require('ws');
const axios = require('axios');

const API_BASE = 'http://localhost:5000/api';
let authToken = null;
let testProjectId = null;

async function authenticate() {
  console.log('🔐 Authenticating...');
  try {
    const response = await axios.post(`${API_BASE}/auth/login`, {
      username: 'admin',
      password: 'admin123!'
    });
    
    authToken = response.data.token;
    axios.defaults.headers.common['Authorization'] = `Bearer ${authToken}`;
    console.log('✅ Authentication successful');
    return true;
  } catch (error) {
    console.log('❌ Authentication failed:', error.message);
    return false;
  }
}

async function getTestProject() {
  try {
    const response = await axios.get(`${API_BASE}/projects`);
    testProjectId = response.data.data?.projects?.[0]?.id;
    console.log('✅ Got test project:', testProjectId);
    return !!testProjectId;
  } catch (error) {
    console.log('❌ Failed to get project:', error.message);
    return false;
  }
}

function testWebSocketConnection() {
  return new Promise((resolve) => {
    console.log('\n🔌 Testing WebSocket Connection...');
    
    const wsUrl = `ws://localhost:5000/ws?token=${encodeURIComponent(authToken)}`;
    console.log('WebSocket URL:', wsUrl);
    
    const ws = new WebSocket(wsUrl);
    let connectionEstablished = false;
    let receivedTaskUpdate = false;
    
    const timeout = setTimeout(() => {
      if (!connectionEstablished) {
        console.log('❌ WebSocket connection timeout');
        ws.close();
        resolve({ 
          connected: false, 
          authenticated: false, 
          realTimeWorking: false,
          error: 'Connection timeout'
        });
      }
    }, 10000);
    
    ws.on('open', () => {
      console.log('🔗 WebSocket connected');
    });
    
    ws.on('message', (data) => {
      try {
        const message = JSON.parse(data.toString());
        console.log('📨 Received message:', message.type);
        
        if (message.type === 'connection_established') {
          connectionEstablished = true;
          console.log('✅ WebSocket authentication successful');
          
          // Test sending a message
          ws.send(JSON.stringify({ type: 'ping' }));
        }
        
        if (message.type === 'pong') {
          console.log('✅ Ping/pong working');
        }
        
        if (message.type === 'task_created' || message.type === 'task_updated') {
          receivedTaskUpdate = true;
          console.log('✅ Received real-time task update');
        }
        
        // If we have everything we need, resolve
        if (connectionEstablished) {
          clearTimeout(timeout);
          setTimeout(() => {
            ws.close();
            resolve({
              connected: true,
              authenticated: true,
              realTimeWorking: receivedTaskUpdate,
              error: null
            });
          }, 2000); // Give time for any task updates
        }
        
      } catch (error) {
        console.log('❌ Error parsing WebSocket message:', error.message);
      }
    });
    
    ws.on('error', (error) => {
      console.log('❌ WebSocket error:', error.message);
      clearTimeout(timeout);
      resolve({
        connected: false,
        authenticated: false,
        realTimeWorking: false,
        error: error.message
      });
    });
    
    ws.on('close', (code, reason) => {
      console.log(`🔌 WebSocket closed: ${code} - ${reason}`);
      if (!connectionEstablished) {
        clearTimeout(timeout);
        resolve({
          connected: false,
          authenticated: false,
          realTimeWorking: false,
          error: `Connection closed: ${code} - ${reason}`
        });
      }
    });
  });
}

async function testRealTimeTaskUpdates() {
  return new Promise((resolve) => {
    console.log('\n📡 Testing Real-Time Task Updates...');
    
    const wsUrl = `ws://localhost:5000/ws?token=${encodeURIComponent(authToken)}`;
    const ws = new WebSocket(wsUrl);
    let taskUpdateReceived = false;
    
    ws.on('open', () => {
      console.log('🔗 WebSocket connected for task update test');
      
      // Create a task to trigger real-time update
      setTimeout(async () => {
        try {
          console.log('🚀 Creating test task...');
          const response = await axios.post(`${API_BASE}/tasks`, {
            project_id: testProjectId,
            title: 'WebSocket Test Task',
            description: 'Testing real-time updates',
            type: 'testing',
            priority: 'medium'
          });
          console.log('✅ Test task created:', response.data.data?.task?.id);
        } catch (error) {
          console.log('❌ Failed to create test task:', error.message);
        }
      }, 1000);
    });
    
    ws.on('message', (data) => {
      try {
        const message = JSON.parse(data.toString());
        console.log('📨 Real-time message:', message.type);
        
        if (message.type === 'task_created' && 
            message.data?.task?.title === 'WebSocket Test Task') {
          taskUpdateReceived = true;
          console.log('✅ Real-time task creation update received!');
          
          // Clean up the test task
          setTimeout(async () => {
            try {
              await axios.delete(`${API_BASE}/tasks/${message.data.task.id}`);
              console.log('🧹 Test task cleaned up');
            } catch (error) {
              console.log('⚠️  Failed to clean up test task:', error.message);
            }
            
            ws.close();
            resolve({ success: true });
          }, 1000);
        }
      } catch (error) {
        console.log('❌ Error parsing real-time message:', error.message);
      }
    });
    
    ws.on('error', (error) => {
      console.log('❌ WebSocket error during real-time test:', error.message);
      resolve({ success: false, error: error.message });
    });
    
    // Timeout after 15 seconds
    setTimeout(() => {
      if (!taskUpdateReceived) {
        console.log('❌ Real-time task update not received (timeout)');
        ws.close();
        resolve({ success: false, error: 'Timeout waiting for real-time update' });
      }
    }, 15000);
  });
}

async function testWithInvalidToken() {
  return new Promise((resolve) => {
    console.log('\n🚫 Testing Invalid Token Rejection...');
    
    const ws = new WebSocket('ws://localhost:5000/ws?token=invalid-token');
    let rejected = false;
    
    const timeout = setTimeout(() => {
      if (!rejected) {
        console.log('❌ Invalid token was not rejected (timeout)');
        ws.close();
        resolve({ rejected: false });
      }
    }, 5000);
    
    ws.on('open', () => {
      console.log('⚠️  Connection opened with invalid token (should not happen)');
    });
    
    ws.on('error', (error) => {
      rejected = true;
      console.log('✅ Invalid token properly rejected:', error.message);
      clearTimeout(timeout);
      resolve({ rejected: true });
    });
    
    ws.on('close', (code, reason) => {
      rejected = true;
      console.log(`✅ Invalid token connection closed: ${code} - ${reason}`);
      clearTimeout(timeout);
      resolve({ rejected: true });
    });
  });
}

async function runTests() {
  console.log('🚀 Starting T008 WebSocket Authentication Fix Tests\n');
  
  // Step 1: Authenticate
  const authenticated = await authenticate();
  if (!authenticated) {
    console.log('❌ Cannot proceed without authentication');
    process.exit(1);
  }
  
  // Step 2: Get test project
  const hasProject = await getTestProject();
  if (!hasProject) {
    console.log('❌ Cannot proceed without a project');
    process.exit(1);
  }
  
  // Step 3: Test WebSocket connection with valid token
  const connectionResult = await testWebSocketConnection();
  
  // Step 4: Test real-time task updates
  const realTimeResult = await testRealTimeTaskUpdates();
  
  // Step 5: Test invalid token rejection
  const invalidTokenResult = await testWithInvalidToken();
  
  // Final Results
  console.log('\n📊 T008 WebSocket Authentication Test Results');
  console.log('=================================================');
  console.log(`🔗 Connection: ${connectionResult.connected ? '✅ SUCCESS' : '❌ FAILED'}`);
  console.log(`🔐 Authentication: ${connectionResult.authenticated ? '✅ SUCCESS' : '❌ FAILED'}`);
  console.log(`📡 Real-Time Updates: ${realTimeResult.success ? '✅ SUCCESS' : '❌ FAILED'}`);
  console.log(`🚫 Invalid Token Rejection: ${invalidTokenResult.rejected ? '✅ SUCCESS' : '❌ FAILED'}`);
  
  const allPassed = connectionResult.connected && 
                    connectionResult.authenticated && 
                    realTimeResult.success && 
                    invalidTokenResult.rejected;
  
  if (allPassed) {
    console.log('\n🎉 ALL TESTS PASSED! T008 WebSocket authentication is working correctly.');
    console.log('🟢 GREEN indicator should show in the UI');
  } else {
    console.log('\n❌ Some tests failed. WebSocket authentication needs fixing.');
    console.log('🔴 RED indicator will show in the UI');
    
    if (connectionResult.error) {
      console.log(`   Connection error: ${connectionResult.error}`);
    }
    if (!realTimeResult.success && realTimeResult.error) {
      console.log(`   Real-time error: ${realTimeResult.error}`);
    }
  }
  
  process.exit(allPassed ? 0 : 1);
}

// Handle cleanup on exit
process.on('SIGINT', () => {
  console.log('\n🛑 Test interrupted');
  process.exit(1);
});

// Run the tests
runTests().catch(error => {
  console.error('❌ Test runner failed:', error);
  process.exit(1);
});
