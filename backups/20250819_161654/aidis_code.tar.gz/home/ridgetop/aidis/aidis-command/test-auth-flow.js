const fetch = require('node-fetch');

async function testAuthFlow() {
    const baseUrl = 'http://localhost:5000/api';
    
    console.log('🔍 TESTING COMPLETE AUTHENTICATION FLOW');
    console.log('=======================================');
    
    try {
        // Step 1: Login
        console.log('\n1️⃣ Attempting login...');
        const loginResponse = await fetch(`${baseUrl}/auth/login`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                username: 'admin',
                password: 'admin123!'
            })
        });
        
        console.log(`Login status: ${loginResponse.status}`);
        
        if (!loginResponse.ok) {
            const errorText = await loginResponse.text();
            console.log('❌ Login failed:', errorText);
            return;
        }
        
        const loginData = await loginResponse.json();
        console.log('✅ Login successful!');
        console.log(`Token expires: ${loginData.expires}`);
        
        const token = loginData.token;
        console.log(`Token: ${token.substring(0, 20)}...`);
        
        // Step 2: Test contexts endpoint
        console.log('\n2️⃣ Testing contexts endpoint...');
        const contextsResponse = await fetch(`${baseUrl}/contexts`, {
            headers: {
                'Authorization': `Bearer ${token}`,
                'Content-Type': 'application/json',
            }
        });
        
        console.log(`Contexts status: ${contextsResponse.status}`);
        
        if (contextsResponse.ok) {
            const contextsData = await contextsResponse.json();
            console.log('✅ Contexts endpoint works!');
            console.log(`Found ${contextsData.data?.length || 0} contexts`);
            if (contextsData.data && contextsData.data.length > 0) {
                console.log(`First context: ${JSON.stringify(contextsData.data[0], null, 2)}`);
            }
        } else {
            const errorText = await contextsResponse.text();
            console.log('❌ Contexts endpoint failed:', errorText);
        }
        
        // Step 3: Test context stats
        console.log('\n3️⃣ Testing contexts stats...');
        const statsResponse = await fetch(`${baseUrl}/contexts/stats`, {
            headers: {
                'Authorization': `Bearer ${token}`,
                'Content-Type': 'application/json',
            }
        });
        
        console.log(`Stats status: ${statsResponse.status}`);
        
        if (statsResponse.ok) {
            const statsData = await statsResponse.json();
            console.log('✅ Context stats works!');
            console.log(`Stats: ${JSON.stringify(statsData, null, 2)}`);
        } else {
            const errorText = await statsResponse.text();
            console.log('❌ Context stats failed:', errorText);
        }
        
    } catch (error) {
        console.error('❌ Test failed with error:', error);
    }
}

testAuthFlow();
