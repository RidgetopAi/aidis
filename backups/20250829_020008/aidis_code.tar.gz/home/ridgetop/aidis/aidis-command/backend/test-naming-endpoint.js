#!/usr/bin/env node

/**
 * Test T010 Naming Registry endpoints specifically
 */

const http = require('http');

async function makeRequest(url, method = 'GET', data = null, headers = {}) {
  return new Promise((resolve, reject) => {
    const urlObj = new URL(url);
    const options = {
      hostname: urlObj.hostname,
      port: urlObj.port || (urlObj.protocol === 'https:' ? 443 : 80),
      path: urlObj.pathname + urlObj.search,
      method,
      headers: {
        'Content-Type': 'application/json',
        ...headers
      }
    };

    const req = http.request(options, (res) => {
      let body = '';
      res.on('data', chunk => body += chunk);
      res.on('end', () => {
        try {
          const parsed = JSON.parse(body);
          resolve({ status: res.statusCode, data: parsed, headers: res.headers });
        } catch (e) {
          resolve({ status: res.statusCode, data: body, headers: res.headers });
        }
      });
    });

    req.on('error', reject);
    
    if (data) {
      req.write(JSON.stringify(data));
    }
    req.end();
  });
}

async function main() {
  console.log('🎯 Testing T010 Naming Registry Endpoints\n');
  
  // 1. Login
  console.log('1️⃣ Logging in...');
  const loginResponse = await makeRequest(
    'http://localhost:5000/api/auth/login',
    'POST',
    { username: 'admin', password: 'admin123!' }
  );
  
  if (loginResponse.status !== 200) {
    console.error('❌ Login failed:', loginResponse.data);
    return;
  }
  
  const token = loginResponse.data.token;
  console.log('✅ Login successful');
  
  // 2. Test naming stats
  console.log('\n2️⃣ Testing naming stats...');
  const statsResponse = await makeRequest(
    'http://localhost:5000/api/naming/stats',
    'GET',
    null,
    { 'Authorization': `Bearer ${token}` }
  );
  
  console.log(`Status: ${statsResponse.status}`);
  console.log('Response:', JSON.stringify(statsResponse.data, null, 2));
  
  // 3. Test name check
  console.log('\n3️⃣ Testing name check...');
  const checkResponse = await makeRequest(
    'http://localhost:5000/api/naming/check/TestName',
    'GET',
    null,
    { 'Authorization': `Bearer ${token}` }
  );
  
  console.log(`Status: ${checkResponse.status}`);
  console.log('Response:', JSON.stringify(checkResponse.data, null, 2));
  
  // 4. Test AIDIS MCP direct
  console.log('\n4️⃣ Testing AIDIS MCP direct...');
  const mcpResponse = await makeRequest(
    'http://localhost:8080/mcp/tools/naming_stats',
    'POST',
    { arguments: {} }
  );
  
  console.log(`Status: ${mcpResponse.status}`);
  console.log('Response:', JSON.stringify(mcpResponse.data, null, 2));
}

main().catch(console.error);
