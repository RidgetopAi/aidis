#!/usr/bin/env node

const fetch = (...args) => import('node-fetch').then(({default: fetch}) => fetch(...args));

async function testContextAuth() {
    console.log('🧪 Testing Context API Authentication...\n');
    
    const baseUrl = 'http://localhost:5000/api';
    
    try {
        // Step 1: Login to get token
        console.log('1️⃣ Logging in...');
        const loginResponse = await fetch(`${baseUrl}/auth/login`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                username: 'admin',
                password: 'admin123!'
            })
        });
        
        const loginData = await loginResponse.json();
        
        if (!loginResponse.ok) {
            console.error('❌ Login failed:', loginData);
            return;
        }
        
        console.log('✅ Login successful');
        console.log('   User:', loginData.user.username);
        console.log('   Token expires:', loginData.expires);
        
        const token = loginData.token;
        
        // Step 2: Test context endpoint WITHOUT token
        console.log('\n2️⃣ Testing context endpoint WITHOUT token...');
        const noTokenResponse = await fetch(`${baseUrl}/contexts`);
        const noTokenData = await noTokenResponse.json();
        
        console.log('   Status:', noTokenResponse.status);
        console.log('   Response:', JSON.stringify(noTokenData, null, 2));
        
        // Step 3: Test context endpoint WITH token
        console.log('\n3️⃣ Testing context endpoint WITH token...');
        const withTokenResponse = await fetch(`${baseUrl}/contexts`, {
            headers: {
                'Authorization': `Bearer ${token}`
            }
        });
        
        const withTokenData = await withTokenResponse.json();
        
        console.log('   Status:', withTokenResponse.status);
        console.log('   Response:', JSON.stringify(withTokenData, null, 2));
        
        // Step 4: Test other context endpoints
        console.log('\n4️⃣ Testing context stats endpoint...');
        const statsResponse = await fetch(`${baseUrl}/contexts/stats`, {
            headers: {
                'Authorization': `Bearer ${token}`
            }
        });
        
        const statsData = await statsResponse.json();
        console.log('   Status:', statsResponse.status);
        console.log('   Response:', JSON.stringify(statsData, null, 2));
        
        console.log('\n🎉 Authentication testing complete!');
        
    } catch (error) {
        console.error('❌ Test failed:', error.message);
    }
}

testContextAuth().catch(console.error);
